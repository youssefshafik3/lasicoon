/*
 * File    : sensor_reader.ino
 * Owner   : Person B
 * Purpose : Reads raw analog values from the LDR (A0) and 2-axis joystick
 *           (VRx on A1, VRy on A2) every ~20 ms, scales each 10-bit reading
 *           to 0..254 (shift right by 2, clamped to 254), and forwards the
 *           4-byte frame {0xFF, x, y, ldr} to the DE10-Lite FPGA over UART
 *           at 9600 baud 8N1 using SoftwareSerial TX on pin D3.
 *
 * NOTE    : This sketch makes NO game decisions (no deadzone, no night-mode
 *           threshold, no turret or game timing). All logic runs on the FPGA.
 *
 * Wiring  : A0 -> LDR voltage divider (5V -> LDR -> A0 -> 10k -> GND)
 *           A1 -> Joystick VRx
 *           A2 -> Joystick VRy
 *           D3 -> 1k / 2k voltage divider (3.33V) -> DE10-Lite JP1 Pin 1 (GPIO[0])
 */

#include <SoftwareSerial.h>

const uint8_t PIN_LDR    = A0;
const uint8_t PIN_JOY_X  = A1;
const uint8_t PIN_JOY_Y  = A2;
const uint8_t PIN_SW_RX  = 2;  // Unused RX pin
const uint8_t PIN_SW_TX  = 3;  // D3 -> voltage divider -> FPGA GPIO[0]

const uint8_t FRAME_SYNC = 0xFF;
const uint8_t MAX_DATA   = 254;
const unsigned long FRAME_PERIOD_MS = 20;

SoftwareSerial fpgaSerial(PIN_SW_RX, PIN_SW_TX);

static uint8_t readScaledClamp(uint8_t analogPin) {
  uint16_t raw = analogRead(analogPin);  // 0..1023
  uint8_t val  = (uint8_t)(raw >> 2);    // 0..255
  if (val > MAX_DATA) {
    val = MAX_DATA;                      // Never collide with 0xFF sync byte
  }
  return val;
}

void setup() {
  fpgaSerial.begin(9600);
}

void loop() {
  uint8_t frame[4];
  frame[0] = FRAME_SYNC;
  frame[1] = readScaledClamp(PIN_JOY_X);
  frame[2] = readScaledClamp(PIN_JOY_Y);
  frame[3] = readScaledClamp(PIN_LDR);

  fpgaSerial.write(frame, 4);
  delay(FRAME_PERIOD_MS);
}
