LIBRARY IEEE;
USE IEEE.std_logic_1164.ALL;
USE IEEE.numeric_std.ALL;

PACKAGE game_pkg IS --THIS FILE IS DEDICATED FOR THE CONSTANTS OF THE GAME

  -- General
  CONSTANT CLK_FREQ          : INTEGER := 50000000;
  CONSTANT N_TARGETS         : INTEGER := 5;
  -- Game states
  TYPE game_state_t IS (S_OFF, S_READY, S_PLAYING, S_GAME_OVER);
  -- Scoring and rules
  CONSTANT PTS_NORMAL        : INTEGER := 1;
  CONSTANT PTS_HARD          : INTEGER := 2;
  CONSTANT PTS_STREAK        : INTEGER := 3;
  CONSTANT LIVES_START       : INTEGER := 3;
  CONSTANT ROUND_SECONDS     : INTEGER := 60;   -- default, may become 45
  CONSTANT STREAK_WINDOW_S   : INTEGER := 10;   -- default, may be changed 
  CONSTANT SCORE_MAX         : INTEGER := 999;
  CONSTANT SCORE_W           : INTEGER := 10;   -- bits needed for 0..999
  -- IR burst (clocks at 50 MHz)
  CONSTANT BURST_HALF_PERIOD : INTEGER := 658;       -- ~38 kHz carrier
  CONSTANT BURST_WINDOW      : INTEGER := 7500000;   -- 150 ms
  CONSTANT BURST_COOLDOWN    : INTEGER := 20000000;  -- 400 ms
  -- Servo PWM (clocks at 50 MHz)
  CONSTANT SERVO_FRAME         : INTEGER := 1000000; -- 20 ms
  CONSTANT SERVO_PULSE_MINIMUM : INTEGER := 52000;   -- 1.04 ms
  CONSTANT SERVO_PULSE_MAXIMUM : INTEGER := 98000;   -- 1.96 ms
  CONSTANT SERVO_FRAME_CYCLES  : INTEGER := SERVO_FRAME;
  CONSTANT PULSE_MIN_CYCLES    : INTEGER := SERVO_PULSE_MINIMUM;
  CONSTANT PULSE_MAX_CYCLES    : INTEGER := SERVO_PULSE_MAXIMUM;
  CONSTANT PULSE_CENTER_CYCLES : INTEGER := 75000;   -- 1.50 ms
  -- Mode 2 target scheduler (milliseconds)
  CONSTANT SCHED_GAP_MIN_MS     : INTEGER := 500;    -- 0.5 s minimum gap
  CONSTANT SCHED_GAP_SPAN_MS    : INTEGER := 1024;   -- +0..1.0 s random span
  CONSTANT SCHED_ONTIME_INIT_MS : INTEGER := 3000;   -- 3.0 s starting window
  CONSTANT SCHED_ONTIME_MIN_MS  : INTEGER := 1200;   -- 1.2 s floor
  CONSTANT SCHED_ONTIME_STEP_MS : INTEGER := 300;    -- shrink step per tier
  CONSTANT SCHED_SHRINK_EVERY   : INTEGER := 3;      -- shrink every 3 hits
  -- Status LEDs (clocks at 50 MHz)
  CONSTANT LED_FLASH_CYCLES     : INTEGER := 10000000; -- 200 ms flash

END PACKAGE game_pkg;